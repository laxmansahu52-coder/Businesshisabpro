package com.example.businesshisab;
import android.app.*; import android.os.*; import android.content.*; import android.view.*; import android.widget.*; import java.util.*;
public class MainActivity extends Activity {
 EditText date,desc,sale,cost,expense; TextView summary,records; ArrayList<String> data=new ArrayList<>();
 android.content.SharedPreferences sp;
 public void onCreate(Bundle b){super.onCreate(b);setContentView(R.layout.activity_main);
 date=findViewById(R.id.date);desc=findViewById(R.id.desc);sale=findViewById(R.id.sale);cost=findViewById(R.id.cost);expense=findViewById(R.id.expense);summary=findViewById(R.id.summary);records=findViewById(R.id.records);
 sp=getSharedPreferences("hisab",0); load(); findViewById(R.id.save).setOnClickListener(v->add()); render();}
 void load(){String s=sp.getString("data",""); if(!s.isEmpty()) data.addAll(Arrays.asList(s.split("\\n",-1)));}
 void add(){String d=date.getText().toString(), ds=desc.getText().toString(); if(d.isEmpty()||ds.isEmpty()){Toast.makeText(this,"Date aur Description bharein",Toast.LENGTH_SHORT).show();return;}
 double a=num(sale),c=num(cost),e=num(expense); data.add(d+"|"+ds+"|"+a+"|"+c+"|"+e); sp.edit().putString("data",String.join("\\n",data)).apply(); desc.setText("");sale.setText("");cost.setText("");expense.setText("");render();}
 double num(EditText e){try{return Double.parseDouble(e.getText().toString());}catch(Exception x){return 0;}}
 void render(){double S=0,C=0,E=0;StringBuilder r=new StringBuilder("Daily Records:\\n\\n"); for(String q:data){if(q.isEmpty())continue;String[] x=q.split("\\|");if(x.length<5)continue;double s=Double.parseDouble(x[2]),c=Double.parseDouble(x[3]),e=Double.parseDouble(x[4]);S+=s;C+=c;E+=e;r.append(x[0]).append(" — ").append(x[1]).append("\\nSale ₹").append((int)s).append(" | Lagat ₹").append((int)c).append(" | Expenses ₹").append((int)e).append("\\nResult: ₹").append((int)Math.abs(s-c-e)).append(s-c-e>=0?" Profit":" Loss").append("\\n\\n");} summary.setText("Total Sale: ₹"+(int)S+"\\nTotal Lagat: ₹"+(int)C+"\\nTotal Expenses: ₹"+(int)E+"\\nNet: ₹"+(int)Math.abs(S-C-E)+(S-C-E>=0?" Profit":" Loss")); records.setText(r.toString());}
}